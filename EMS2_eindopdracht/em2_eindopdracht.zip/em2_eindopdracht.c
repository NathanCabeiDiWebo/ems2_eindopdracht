/*
 * EMS2 - MCXA156 RTC + GREEN LED + SPI RTOS
 *
 * RTC: MCP7940M, LPI2C0, address 0x6F
 * LED: GPIO3 pin 13, active-low
 * SPI: LPSPI0 slave, PCS0
 *
 * SPI protocol:
 * SET_DATE: one 20-byte transfer containing YYYY-MM-DD HH:MM:SS
 * GET_DATE: one 20-byte request transfer, followed by a 20-byte
 *           response transfer containing YYYY-MM-DD HH:MM:SS or ERROR
 */

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>

#include "fsl_debug_console.h"
#include "fsl_lpi2c.h"
#include "fsl_lpspi.h"
#include "fsl_common.h"
#include "fsl_clock.h"
#include "fsl_reset.h"
#include "fsl_port.h"
#include "fsl_gpio.h"

#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"

#include <FreeRTOS.h>
#include <task.h>
#include <semphr.h>

#include <FreeRTOS_POSIX/pthread.h>
#include <FreeRTOS_POSIX/unistd.h>
#include <FreeRTOS_POSIX/errno.h>

/* Configuration */

#define RTC_ADDRESS             0x6FU
#define RTC_REGISTER_COUNT      7U

#define RTC_SECONDS_REGISTER    0U
#define RTC_MINUTES_REGISTER    1U
#define RTC_HOURS_REGISTER      2U
#define RTC_WEEKDAY_REGISTER    3U
#define RTC_DATE_REGISTER       4U
#define RTC_MONTH_REGISTER      5U
#define RTC_YEAR_REGISTER       6U

#define LED_GPIO                GPIO3
#define LED_PORT                PORT3
#define LED_PIN                 13U

#define SPI_TRANSFER_SIZE       20U
#define DATETIME_SIZE           20U

#define APP_THREAD_STACK_SIZE   1024U
#define WORKER_STACK_SIZE       2048U

/* RTC date/time */

typedef struct
{
    uint8_t year;
    uint8_t month;
    uint8_t date;
    uint8_t hours;
    uint8_t minutes;
    uint8_t seconds;
} rtc_datetime_t;

/* SPI variables */

static uint8_t spi_rx_data[SPI_TRANSFER_SIZE];
static uint8_t spi_tx_data[SPI_TRANSFER_SIZE];

static lpspi_slave_handle_t spi_slave_handle;

static SemaphoreHandle_t spi_transfer_semaphore = NULL;
static SemaphoreHandle_t rtc_mutex = NULL;
static SemaphoreHandle_t rtc_ready_semaphore = NULL;

static volatile status_t spi_transfer_status = kStatus_Success;

/* Error handling */

static void check(int error)
{
    if (error != 0)
    {
        PRINTF("RTOS/POSIX error: %d\r\n", error);

        while (1)
        {
        }
    }
}

/* RTC helper functions */

static uint8_t decimal_to_bcd(uint8_t value)
{
    return (uint8_t)(((value / 10U) << 4U) | (value % 10U));
}

static uint8_t bcd_to_decimal(uint8_t value)
{
    return (uint8_t)(((value >> 4U) * 10U) + (value & 0x0FU));
}

static bool rtc_bcd_is_valid(uint8_t value)
{
    return (((value >> 4U) & 0x0FU) <= 9U) &&
           ((value & 0x0FU) <= 9U);
}

static status_t rtc_write_registers(uint8_t start_register,
                                    const uint8_t *data,
                                    size_t length)
{
    uint8_t write_buffer[RTC_REGISTER_COUNT + 1U];
    status_t status;

    if ((data == NULL) ||
        (length == 0U) ||
        (length > RTC_REGISTER_COUNT))
    {
        return kStatus_InvalidArgument;
    }

    write_buffer[0] = start_register;
    memcpy(&write_buffer[1], data, length);

    status = LPI2C_MasterStart(LPI2C0_PERIPHERAL,
                               RTC_ADDRESS,
                               kLPI2C_Write);

    if (status != kStatus_Success)
    {
        return status;
    }

    status = LPI2C_MasterSend(LPI2C0_PERIPHERAL,
                              write_buffer,
                              length + 1U);

    LPI2C_MasterStop(LPI2C0_PERIPHERAL);

    return status;
}

static status_t rtc_read_registers(uint8_t start_register,
                                   uint8_t *data,
                                   size_t length)
{
    status_t status;

    if ((data == NULL) ||
        (length == 0U) ||
        (length > RTC_REGISTER_COUNT))
    {
        return kStatus_InvalidArgument;
    }

    status = LPI2C_MasterStart(LPI2C0_PERIPHERAL,
                               RTC_ADDRESS,
                               kLPI2C_Write);

    if (status != kStatus_Success)
    {
        return status;
    }

    status = LPI2C_MasterSend(LPI2C0_PERIPHERAL,
                              &start_register,
                              1U);

    if (status != kStatus_Success)
    {
        LPI2C_MasterStop(LPI2C0_PERIPHERAL);
        return status;
    }

    status = LPI2C_MasterRepeatedStart(LPI2C0_PERIPHERAL,
                                       RTC_ADDRESS,
                                       kLPI2C_Read);

    if (status != kStatus_Success)
    {
        LPI2C_MasterStop(LPI2C0_PERIPHERAL);
        return status;
    }

    status = LPI2C_MasterReceive(LPI2C0_PERIPHERAL,
                                 data,
                                 length);

    LPI2C_MasterStop(LPI2C0_PERIPHERAL);

    return status;
}

static bool is_leap_year(uint16_t year)
{
    return ((year % 4U) == 0U) &&
           (((year % 100U) != 0U) || ((year % 400U) == 0U));
}

static uint8_t days_in_month(uint16_t year, uint8_t month)
{
    static const uint8_t month_days[12] = {
        31U, 28U, 31U, 30U, 31U, 30U,
        31U, 31U, 30U, 31U, 30U, 31U
    };

    if ((month < 1U) || (month > 12U))
    {
        return 0U;
    }

    if ((month == 2U) && is_leap_year(year))
    {
        return 29U;
    }

    return month_days[month - 1U];
}

static uint8_t calculate_weekday(uint16_t year,
                                 uint8_t month,
                                 uint8_t day)
{
    static const uint8_t offsets[12] = {
        0U, 3U, 2U, 5U, 0U, 3U,
        5U, 1U, 4U, 6U, 2U, 4U
    };

    uint16_t adjusted_year = year;

    if (month < 3U)
    {
        adjusted_year--;
    }

    uint8_t weekday = (uint8_t)(
        (adjusted_year +
         adjusted_year / 4U -
         adjusted_year / 100U +
         adjusted_year / 400U +
         offsets[month - 1U] +
         day) % 7U
    );

    return (uint8_t)(weekday + 1U);
}

/* Validate and parse exactly YYYY-MM-DD HH:MM:SS */

static bool rtc_parse_datetime(const uint8_t *buffer,
                               rtc_datetime_t *datetime)
{
    uint16_t full_year;

    if ((buffer == NULL) || (datetime == NULL))
    {
        return false;
    }

    if (buffer[19] != '\0')
    {
        return false;
    }

    if ((buffer[4] != '-') ||
        (buffer[7] != '-') ||
        (buffer[10] != ' ') ||
        (buffer[13] != ':') ||
        (buffer[16] != ':'))
    {
        return false;
    }

    for (uint8_t i = 0U; i < 19U; i++)
    {
        if ((i == 4U) || (i == 7U) ||
            (i == 10U) || (i == 13U) || (i == 16U))
        {
            continue;
        }

        if ((buffer[i] < '0') || (buffer[i] > '9'))
        {
            return false;
        }
    }

    full_year = (uint16_t)(
        (buffer[0] - '0') * 1000U +
        (buffer[1] - '0') * 100U +
        (buffer[2] - '0') * 10U +
        (buffer[3] - '0')
    );

    if ((full_year < 2000U) || (full_year > 2099U))
    {
        return false;
    }

    datetime->year = (uint8_t)(full_year - 2000U);

    datetime->month = (uint8_t)(
        (buffer[5] - '0') * 10U + (buffer[6] - '0')
    );

    datetime->date = (uint8_t)(
        (buffer[8] - '0') * 10U + (buffer[9] - '0')
    );

    datetime->hours = (uint8_t)(
        (buffer[11] - '0') * 10U + (buffer[12] - '0')
    );

    datetime->minutes = (uint8_t)(
        (buffer[14] - '0') * 10U + (buffer[15] - '0')
    );

    datetime->seconds = (uint8_t)(
        (buffer[17] - '0') * 10U + (buffer[18] - '0')
    );

    if ((datetime->month < 1U) || (datetime->month > 12U) ||
        (datetime->date < 1U) ||
        (datetime->date > days_in_month(full_year, datetime->month)) ||
        (datetime->hours > 23U) ||
        (datetime->minutes > 59U) ||
        (datetime->seconds > 59U))
    {
        return false;
    }

    return true;
}

/* Caller holds rtc_mutex. */

static status_t rtc_set_datetime(const rtc_datetime_t *datetime)
{
    uint8_t registers[RTC_REGISTER_COUNT];
    uint8_t old_weekday_register;
    uint16_t full_year;
    status_t status;

    if (datetime == NULL)
    {
        return kStatus_InvalidArgument;
    }

    full_year = (uint16_t)(2000U + datetime->year);

    status = rtc_read_registers(RTC_WEEKDAY_REGISTER,
                                &old_weekday_register,
                                1U);

    if (status != kStatus_Success)
    {
        return status;
    }

    registers[RTC_SECONDS_REGISTER] =
        (uint8_t)(decimal_to_bcd(datetime->seconds) | 0x80U);

    registers[RTC_MINUTES_REGISTER] =
        decimal_to_bcd(datetime->minutes);

    registers[RTC_HOURS_REGISTER] =
        decimal_to_bcd(datetime->hours);

    registers[RTC_WEEKDAY_REGISTER] =
        (uint8_t)((old_weekday_register & 0x08U) |
                  calculate_weekday(full_year,
                                    datetime->month,
                                    datetime->date));

    registers[RTC_DATE_REGISTER] =
        decimal_to_bcd(datetime->date);

    registers[RTC_MONTH_REGISTER] =
        (uint8_t)(decimal_to_bcd(datetime->month) |
                  (is_leap_year(full_year) ? 0x20U : 0U));

    registers[RTC_YEAR_REGISTER] =
        decimal_to_bcd(datetime->year);

    return rtc_write_registers(RTC_SECONDS_REGISTER,
                               registers,
                               RTC_REGISTER_COUNT);
}

/* Caller holds rtc_mutex. */

static status_t rtc_read_datetime(rtc_datetime_t *datetime)
{
    uint8_t registers[RTC_REGISTER_COUNT];
    status_t status;

    if (datetime == NULL)
    {
        return kStatus_InvalidArgument;
    }

    status = rtc_read_registers(RTC_SECONDS_REGISTER,
                                registers,
                                RTC_REGISTER_COUNT);

    if (status != kStatus_Success)
    {
        return status;
    }

    uint8_t seconds = registers[RTC_SECONDS_REGISTER] & 0x7FU;
    uint8_t minutes = registers[RTC_MINUTES_REGISTER] & 0x7FU;
    uint8_t hours = registers[RTC_HOURS_REGISTER] & 0x3FU;
    uint8_t date = registers[RTC_DATE_REGISTER] & 0x3FU;
    uint8_t month = registers[RTC_MONTH_REGISTER] & 0x1FU;
    uint8_t year = registers[RTC_YEAR_REGISTER];

    if (!rtc_bcd_is_valid(seconds) ||
        !rtc_bcd_is_valid(minutes) ||
        !rtc_bcd_is_valid(hours) ||
        !rtc_bcd_is_valid(date) ||
        !rtc_bcd_is_valid(month) ||
        !rtc_bcd_is_valid(year))
    {
        return kStatus_Fail;
    }

    datetime->seconds = bcd_to_decimal(seconds);
    datetime->minutes = bcd_to_decimal(minutes);
    datetime->hours = bcd_to_decimal(hours);
    datetime->date = bcd_to_decimal(date);
    datetime->month = bcd_to_decimal(month);
    datetime->year = bcd_to_decimal(year);

    if ((datetime->seconds > 59U) ||
        (datetime->minutes > 59U) ||
        (datetime->hours > 23U) ||
        (datetime->month < 1U) ||
        (datetime->month > 12U) ||
        (datetime->date < 1U) ||
        (datetime->date >
         days_in_month((uint16_t)(2000U + datetime->year),
                       datetime->month)))
    {
        return kStatus_Fail;
    }

    return kStatus_Success;
}

/* Format YYYY-MM-DD HH:MM:SS plus null terminator. */

static void rtc_format_datetime(char *buffer,
                                const rtc_datetime_t *datetime)
{
    buffer[0] = '2';
    buffer[1] = '0';
    buffer[2] = (char)('0' + datetime->year / 10U);
    buffer[3] = (char)('0' + datetime->year % 10U);
    buffer[4] = '-';
    buffer[5] = (char)('0' + datetime->month / 10U);
    buffer[6] = (char)('0' + datetime->month % 10U);
    buffer[7] = '-';
    buffer[8] = (char)('0' + datetime->date / 10U);
    buffer[9] = (char)('0' + datetime->date % 10U);
    buffer[10] = ' ';
    buffer[11] = (char)('0' + datetime->hours / 10U);
    buffer[12] = (char)('0' + datetime->hours % 10U);
    buffer[13] = ':';
    buffer[14] = (char)('0' + datetime->minutes / 10U);
    buffer[15] = (char)('0' + datetime->minutes % 10U);
    buffer[16] = ':';
    buffer[17] = (char)('0' + datetime->seconds / 10U);
    buffer[18] = (char)('0' + datetime->seconds % 10U);
    buffer[19] = '\0';
}

static void rtc_read_and_print_datetime(void)
{
    rtc_datetime_t datetime;
    char datetime_string[DATETIME_SIZE];
    status_t status;

    if (xSemaphoreTake(rtc_mutex, portMAX_DELAY) != pdTRUE)
    {
        return;
    }

    status = rtc_read_datetime(&datetime);
    xSemaphoreGive(rtc_mutex);

    if (status != kStatus_Success)
    {
        PRINTF("RTC read failed: %d\r\n", status);
        return;
    }

    rtc_format_datetime(datetime_string, &datetime);
    PRINTF("RTC: %s\r\n", datetime_string);
}

/* Green LED */

static void green_led_init(void)
{
    gpio_pin_config_t led_config = {
        .pinDirection = kGPIO_DigitalOutput,
        .outputLogic = 1U
    };

    CLOCK_EnableClock(kCLOCK_GatePORT3);
    CLOCK_EnableClock(kCLOCK_GateGPIO3);

    RESET_ReleasePeripheralReset(kGPIO3_RST_SHIFT_RSTn);
    RESET_ReleasePeripheralReset(kPORT3_RST_SHIFT_RSTn);

    PORT_SetPinMux(LED_PORT, LED_PIN, kPORT_MuxAsGpio);
    GPIO_PinInit(LED_GPIO, LED_PIN, &led_config);
}

/* SPI interrupt and callback */

void LPSPI0_IRQHandler(void)
{
    LPSPI_SlaveTransferHandleIRQ(LPSPI0, &spi_slave_handle);
}

static void spi_slave_callback(LPSPI_Type *base,
                               lpspi_slave_handle_t *handle,
                               status_t status,
                               void *userData)
{
    BaseType_t higher_priority_task_woken = pdFALSE;

    (void)base;
    (void)handle;
    (void)userData;

    spi_transfer_status = status;

    if (spi_transfer_semaphore != NULL)
    {
        xSemaphoreGiveFromISR(spi_transfer_semaphore,
                              &higher_priority_task_woken);

        portYIELD_FROM_ISR(higher_priority_task_woken);
    }
}

static void spi_init(void)
{
    lpspi_slave_config_t slave_config;

    LPSPI_SlaveGetDefaultConfig(&slave_config);
    slave_config.whichPcs = kLPSPI_Pcs0;

    LPSPI_SlaveInit(LPSPI0, &slave_config);

    LPSPI_SlaveTransferCreateHandle(
        LPSPI0,
        &spi_slave_handle,
        spi_slave_callback,
        NULL
    );

#ifdef configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY
    NVIC_SetPriority(
        LPSPI0_IRQn,
        configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY
    );
#else
    NVIC_SetPriority(LPSPI0_IRQn, 5U);
#endif

    EnableIRQ(LPSPI0_IRQn);
}

/* Perform one 20-byte SPI transfer. */

static status_t spi_do_transfer(void)
{
    lpspi_transfer_t transfer;
    status_t status;

    memset(spi_rx_data, 0, sizeof(spi_rx_data));

    transfer.txData = spi_tx_data;
    transfer.rxData = spi_rx_data;
    transfer.dataSize = SPI_TRANSFER_SIZE;
    transfer.configFlags = 0U;

    status = LPSPI_SlaveTransferNonBlocking(
        LPSPI0,
        &spi_slave_handle,
        &transfer
    );

    if (status != kStatus_Success)
    {
        return status;
    }

    if (xSemaphoreTake(spi_transfer_semaphore,
                       portMAX_DELAY) != pdTRUE)
    {
        return kStatus_Fail;
    }

    return spi_transfer_status;
}

/* Prepare a short text response in the SPI transmit buffer. */

static void spi_prepare_response(const char *response)
{
    memset(spi_tx_data, 0, sizeof(spi_tx_data));
    strncpy((char *)spi_tx_data, response, SPI_TRANSFER_SIZE - 1U);
}

/* RTOS worker threads */

static void *rtc_thread(void *arg)
{
    uint8_t seconds_register;
    status_t status;

    (void)arg;

    PRINTF("RTC thread started.\r\n");

    if (xSemaphoreTake(rtc_mutex, portMAX_DELAY) == pdTRUE)
    {
        status = rtc_read_registers(RTC_SECONDS_REGISTER,
                                    &seconds_register,
                                    1U);

        if ((status == kStatus_Success) &&
            ((seconds_register & 0x80U) == 0U))
        {
            seconds_register |= 0x80U;

            status = rtc_write_registers(
                RTC_SECONDS_REGISTER,
                &seconds_register,
                1U
            );
        }

        xSemaphoreGive(rtc_mutex);
    }
    else
    {
        status = kStatus_Fail;
    }

    if (status != kStatus_Success)
    {
        PRINTF("RTC startup check failed: %d\r\n", status);
    }
    else
    {
        PRINTF("RTC ready; existing time preserved.\r\n");
    }

    xSemaphoreGive(rtc_ready_semaphore);

    while (1)
    {
        rtc_read_and_print_datetime();
        sleep(1);
    }

    return NULL;
}

static void *led_thread(void *arg)
{
    (void)arg;

    PRINTF("Green LED thread started.\r\n");

    while (1)
    {
        GPIO_PortToggle(LED_GPIO, 1UL << LED_PIN);
        sleep(1);
    }

    return NULL;
}

/*
 * SPI command protocol:
 *
 * SET_DATE: one transfer containing YYYY-MM-DD HH:MM:SS.
 * GET_DATE: receive request, read RTC, then transmit response
 *           in a second transfer.
 */
static void *spi_thread(void *arg)
{
    status_t status;
    status_t rtc_status;
    rtc_datetime_t datetime;

    char command[SPI_TRANSFER_SIZE + 1U];
    char datetime_string[DATETIME_SIZE];
    bool send_response;

    (void)arg;

    PRINTF("SPI thread started.\r\n");
    PRINTF("Waiting for SET_DATE / GET_DATE commands...\r\n");

    xSemaphoreTake(rtc_ready_semaphore, portMAX_DELAY);

    while (1)
    {
        /* Receive a command or datetime from ESP1. */

        memset(spi_tx_data, 0, sizeof(spi_tx_data));

        status = spi_do_transfer();

        if (status != kStatus_Success)
        {
            PRINTF("SPI command transfer failed: %d\r\n", status);
            sleep(1);
            continue;
        }

        memcpy(command, spi_rx_data, SPI_TRANSFER_SIZE);
        command[SPI_TRANSFER_SIZE] = '\0';

        PRINTF("SPI command received: %s\r\n", command);

        send_response = false;

        /*
         * SET_DATE: ESP1 sends the 20-byte datetime directly.
         * This command uses only one SPI transfer.
         */
        if (rtc_parse_datetime(spi_rx_data, &datetime))
        {
            if (xSemaphoreTake(rtc_mutex, portMAX_DELAY) == pdTRUE)
            {
                rtc_status = rtc_set_datetime(&datetime);
                xSemaphoreGive(rtc_mutex);
            }
            else
            {
                rtc_status = kStatus_Fail;
            }

            if (rtc_status == kStatus_Success)
            {
                rtc_format_datetime(datetime_string, &datetime);

                PRINTF("RTC updated successfully: %s\r\n",
                       datetime_string);
            }
            else
            {
                PRINTF("RTC update failed: %d\r\n", rtc_status);
            }
        }

        /*
         * GET_DATE: read the RTC and prepare the response.
         * ESP1 will clock out the response in a second transfer.
         */
        else if (strncmp(command, "GET_DATE", 8U) == 0)
        {
            if (xSemaphoreTake(rtc_mutex, portMAX_DELAY) == pdTRUE)
            {
                rtc_status = rtc_read_datetime(&datetime);
                xSemaphoreGive(rtc_mutex);
            }
            else
            {
                rtc_status = kStatus_Fail;
            }

            if (rtc_status == kStatus_Success)
            {
                rtc_format_datetime(datetime_string, &datetime);

                PRINTF("RTC date/time requested: %s\r\n",
                       datetime_string);

                spi_prepare_response(datetime_string);
            }
            else
            {
                PRINTF("RTC read failed: %d\r\n", rtc_status);
                spi_prepare_response("ERROR");
            }

            send_response = true;
        }
        else
        {
            PRINTF("Unknown SPI command or invalid date/time.\r\n");
        }

        if (send_response)
        {
            /*
             * Prepare/arm the second transfer so ESP1 can clock
             * out the RTC response.
             */
            status = spi_do_transfer();

            if (status != kStatus_Success)
            {
                PRINTF("SPI response transfer failed: %d\r\n", status);
            }
            else
            {
                PRINTF("SPI response sent to ESP1: %s\r\n",
                       (char *)spi_tx_data);
            }
        }

        PRINTF("-------------------------\r\n");
    }

    return NULL;
}

/* Application thread */

static void *main_thread(void *arg)
{
    pthread_t rtc_thread_id;
    pthread_t led_thread_id;
    pthread_t spi_thread_id;
    pthread_attr_t attr;
    int result;

    (void)arg;

    PRINTF("Application thread started.\r\n");

    result = pthread_attr_init(&attr);
    check(result);

    result = pthread_attr_setstacksize(&attr, WORKER_STACK_SIZE);
    PRINTF("Set worker stack size: %d\r\n", result);
    check(result);

    result = pthread_create(&rtc_thread_id, &attr, rtc_thread, NULL);
    check(result);

    result = pthread_create(&led_thread_id, &attr, led_thread, NULL);
    check(result);

    result = pthread_create(&spi_thread_id, &attr, spi_thread, NULL);
    check(result);

    result = pthread_attr_destroy(&attr);
    check(result);

    while (1)
    {
        sleep(1);
    }

    return NULL;
}

/* Main */

int main(void)
{
    pthread_attr_t main_thread_attr;
    pthread_t main_thread_handle;
    struct sched_param main_thread_sched_param;

    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitDebugConsole();
    BOARD_InitPeripherals();

    green_led_init();

    spi_transfer_semaphore = xSemaphoreCreateBinary();
    rtc_mutex = xSemaphoreCreateMutex();
    rtc_ready_semaphore = xSemaphoreCreateBinary();

    if ((spi_transfer_semaphore == NULL) ||
        (rtc_mutex == NULL) ||
        (rtc_ready_semaphore == NULL))
    {
        PRINTF("ERROR: Could not create RTOS synchronization objects.\r\n");

        while (1)
        {
        }
    }

    spi_init();

    PRINTF("\r\n");
    PRINTF("====================================\r\n");
    PRINTF(" MCXA156 RTC + LED + SPI RTOS\r\n");
    PRINTF("====================================\r\n");
    PRINTF("RTC: LPI2C0, address 0x6F\r\n");
    PRINTF("Green LED: GPIO3 pin 13, active-low\r\n");
    PRINTF("SPI: LPSPI0 slave, PCS0\r\n");
    PRINTF("SPI protocol: SET_DATE / GET_DATE\r\n\r\n");

    check(pthread_attr_init(&main_thread_attr));

    check(pthread_attr_setdetachstate(
        &main_thread_attr,
        PTHREAD_CREATE_DETACHED
    ));

    check(pthread_attr_setstacksize(
        &main_thread_attr,
        APP_THREAD_STACK_SIZE
    ));

    check(pthread_attr_getschedparam(
        &main_thread_attr,
        &main_thread_sched_param
    ));

    main_thread_sched_param.sched_priority =
        sched_get_priority_max(SCHED_OTHER);

    check(pthread_attr_setschedparam(
        &main_thread_attr,
        &main_thread_sched_param
    ));

    check(pthread_create(
        &main_thread_handle,
        &main_thread_attr,
        main_thread,
        NULL
    ));

    check(pthread_attr_destroy(&main_thread_attr));

    vTaskStartScheduler();

    while (1)
    {
    }

    return EXIT_SUCCESS;
}